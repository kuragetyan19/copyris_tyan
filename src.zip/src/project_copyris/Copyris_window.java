package project_copyris;

import javax.swing.JFrame;

/*
 *
 * 				class "Copyris_window"
 * 					JFrameを継承した、ウィンドウ作成用クラス
 *
 * 				作成日 : 2021/2/1
 * 				作成者 : クラゲちゃん
 *
 */

public class Copyris_window extends JFrame {
	//ウィンドウ
	public Copyris_window(String Window_name,int width,int height) {

		super(Window_name); //ウィンドウを作る
		setDefaultCloseOperation(EXIT_ON_CLOSE); //閉じるボタンデフォルト設定
		setSize(width, height); //ウィンドウサイズ
		setLocationRelativeTo(null); //ウィンドウ位置デフォルト設定
		setResizable(false); //リサイズ可能かどうか設定
		setLayout(null); //レイアウト設定
	}
}
