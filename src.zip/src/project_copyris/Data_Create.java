package project_copyris;

import java.io.Serializable;

public class Data_Create implements Serializable{
	private static final long serialVersionUID = -5800142262424925545L;

	private String str[] = new String[18];

	public Data_Create() {

	}

	public void SetData(int num,String str) {
		this.str[num] = str;
	}

	public String GetData(int num) {
		return str[num];
	}
}
