package project_copyris;

import java.awt.datatransfer.Clipboard;

import javax.swing.JButton;
import javax.swing.JLabel;

/*
*
* 				class "Draw_Button"
* 					JButtonを継承した、ボタン作成用クラス(コピー用)
*
* 				作成日 : 2021/2/1
* 				作成者 : クラゲちゃん
*
*/

public class Draw_Button extends JButton {

	private int mynumber;
	private String str[] = new String[18];

	public Draw_Button() {

	}

	public Draw_Button(String Button_Txt,int x,int y,int width,int height,JLabel jl,Clipboard cb,Copyris_window cw,int mynumber,String str[]) {

		setText(Button_Txt); // ボタンに表示するテキスト
		setFocusPainted(false); //文字の枠線除去
		setBounds(x, y, width, height); //ボタンサイズの設定
		this.mynumber = mynumber;
		this.str = str;

		addMouseListener(new MouseEvent(jl,cb,new Popup_Menu(cw,this),this));
	}

	public int GetMynumber() {
		return mynumber;
	}

	public String Getstr(int num) {
		return str[num];
	}
}
