package project_copyris;

import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

/*
*
* 				class "Draw_Button_OnTop"
* 					JButtonを継承した、ボタン作成用クラス(最前面に表示するボタン)
*
* 				作成日 : 2021/2/4
* 				作成者 : クラゲちゃん
*
*/

public class Draw_Button_OnTop extends JButton {

	private boolean OntopText = false;

	public Draw_Button_OnTop(int x,int y,int width,int height,JLabel jl,Clipboard cb,JFrame frame,JLabel icon) {
		setFocusPainted(false); //文字の枠線除去
		setBounds(x, y, width, height); //ボタンサイズの設定

		setText("常に最前面に表示");

		//ボタンが押されたら、コピーしましたと表示
		addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(Toolkit.getDefaultToolkit().isAlwaysOnTopSupported()) {
					if(OntopText == false){
						frame.setAlwaysOnTop(true);
						icon.setVisible(true);
						OntopText = true;
					}
					else if(OntopText == true) {
						frame.setAlwaysOnTop(false);
						icon.setVisible(false);
						OntopText = false;
					}
				}
			}

		});
	}

	public boolean GetOntopText() {
		return OntopText;
	}

}
