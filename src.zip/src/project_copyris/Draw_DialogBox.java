package project_copyris;

import javax.swing.JDialog;
import javax.swing.JOptionPane;

public class Draw_DialogBox {

	//ダイアログボックス
	private JDialog jd;

	public void create_DialogBox() {
		//メッセージダイアログボックスの生成
		JOptionPane optionPane = new JOptionPane();
		optionPane.setMessage("コピーしました"); // メッセージテキストの設定
		optionPane.setMessageType(JOptionPane.PLAIN_MESSAGE); //メッセージ種類

		//ダイアログボックスウィンドウネーム
		jd = optionPane.createDialog("お知らせ");
	}

	public JDialog GetDialog() {
		return jd;
	}
}
