package project_copyris;

import javax.swing.ImageIcon;
import javax.swing.JLabel;

/*
*
* 				class "Draw_Image"
* 					作成したクラスを生成、動作させるメインクラス
*
* 				作成日 : 2021/2/8
* 				作成者 : クラゲちゃん
*
*/

public class Draw_Image extends JLabel{

	private ImageIcon img;

	public Draw_Image(String filePath,int hx,int hy) {
		//ファイルパスの取得
		img = new ImageIcon(filePath);

		setIcon(img);
		setBounds(hx,hy,img.getIconWidth(),img.getIconHeight());
	}

	//public void paintComponent(Graphics g) {
		//super.paintComponent(g);

		//画像描画
		//g.drawImage(img, x, y, width, height, this);
	//}

	public ImageIcon Getimg() {
		return img;
	}
}
