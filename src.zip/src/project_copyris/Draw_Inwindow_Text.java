package project_copyris;

import javax.swing.JPanel;

public class Draw_Inwindow_Text extends JPanel {

	int txt_x;
	int txt_y;
	String disp_text;

	public Draw_Inwindow_Text() {

	}

	public Draw_Inwindow_Text(int x,int y,String txt){
		txt_x = x;
		txt_y = y;
		disp_text = txt;
	}

	/*public void paintComponent(Graphics g) {
		super.paintComponent(g);
		g.drawString(disp_text, txt_x, txt_y);
	}*/
}
