package project_copyris;

import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.MouseListener;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.JLabel;

public class MouseEvent implements MouseListener {

	JLabel jlabel;
	Clipboard cboard;
	Draw_Button dbutton;
	Popup_Menu pmenu;

	public MouseEvent(JLabel jl,Clipboard cb,Popup_Menu pm,Draw_Button db) {
		jlabel = jl;
		cboard = cb;
		pmenu = pm;
		dbutton = db;
	}

	@Override
	public void mouseClicked(java.awt.event.MouseEvent e) {

			if(javax.swing.SwingUtilities.isLeftMouseButton(e)){
				StringSelection sselection = new StringSelection(dbutton.getText());
				cboard.setContents(sselection, null);

				jlabel.setVisible(true);

				TimerTask task = new TimerTask() {
					@Override
					public void run() {
						jlabel.setVisible(false);
					}
				};

					Timer timer = new Timer();
					timer.schedule(task,1000);
				}
			else if(javax.swing.SwingUtilities.isRightMouseButton(e)){
				pmenu.GetpMenu().show(e.getComponent(), e.getX(), e.getY());
			}
		}

	@Override
	public void mousePressed(java.awt.event.MouseEvent e) {

	}

	@Override
	public void mouseReleased(java.awt.event.MouseEvent e) {

	}

	@Override
	public void mouseEntered(java.awt.event.MouseEvent e) {

	}

	@Override
	public void mouseExited(java.awt.event.MouseEvent e) {

	}


}
