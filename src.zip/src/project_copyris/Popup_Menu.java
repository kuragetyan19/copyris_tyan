package project_copyris;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;

public class Popup_Menu extends JLabel{

	private JPopupMenu popupmenu = new JPopupMenu();

	public Popup_Menu() {
		addPopupMenuItem("テキスト編集", new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent ae) {
				System.out.println("aaaaaa");
			}
		});
	}

	public Popup_Menu(Copyris_window cw,Draw_Button db) {
		addPopupMenuItem("テキスト編集", new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent ae) {
				//ウィンドウから一旦ボタンをリムーブ
				cw.remove(db);

				//テキスト入力ダイアログ表示
				String Value = JOptionPane.showInputDialog("テキストを入力してください");
				if(Value != null) {
					db.setText(Value);
					cw.add(db);

					try{
						ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("Text/Button_Data.bin"));

						Data_Create dc = new Data_Create();

						for(int i = 0;i < 18;i++) {
							if(db.GetMynumber() == i) {
								dc.SetData(db.GetMynumber(), Value);
							} else {
								dc.SetData(i, db.Getstr(i));
							}
						}
						oos.writeObject(dc);
						oos.close();

					}catch (FileNotFoundException e) {
						e.printStackTrace();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
		});
	}

	// メニュー項目を追加
	  private JMenuItem addPopupMenuItem(String name, ActionListener al){
	    JMenuItem item = new JMenuItem(name);
	    item.addActionListener(al);
	    popupmenu.add(item);
	    return item;
	  }

	  public JPopupMenu GetpMenu() {
		  return popupmenu;
	  }
}
