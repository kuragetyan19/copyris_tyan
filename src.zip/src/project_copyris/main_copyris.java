package project_copyris;

import java.awt.Color;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import javax.swing.JLabel;

/*
*
* 				class "main_copyris"
* 					作成したクラスを生成、動作させるメインクラス
*
* 				作成日 : 2021/2/1
* 				作成者 : クラゲちゃん
*
*/

public class main_copyris {

	static Data_Create dataCreate;

	public static void main(String[] args) {

		if(!fileExists("Text/Button_Data.bin")){
			InitStrData();
		}

		//定数定義
		final int BUTTON_PLUS_X = 240;
		final int BUTTON_START_X = 50;
		final int BUTTON_PLUS_Y = 100;
		final int BUTTON_START_Y = 70;


		String binstr[] = new String[18];
		//バイナリファイル読み込み
		try{
			ObjectInputStream ois = new ObjectInputStream(new FileInputStream("Text/Button_Data.bin"));

			Data_Create dc = (Data_Create) ois.readObject();
			ois.close();

			for(int i = 0;i< 18;i++){
				binstr[i] = dc.GetData(i);
			}

		}catch (FileNotFoundException e) {
			System.out.println("57 : main_copyris.java : FileNotFoundException");
            e.printStackTrace();
        } catch (IOException e) {
        	System.out.println("60 : main_copyris.java : IOException");
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
        	System.out.println("63 : main_copyris.java : ClassNotFoundException");
            e.printStackTrace();
        }

		//クリップボード用ローカル変数
		Clipboard cb = Toolkit.getDefaultToolkit().getSystemClipboard();

		//ウィンドウ生成
		Copyris_window copyris_window =  new Copyris_window("コピリスちゃん", 1080, 720);

		//チェック画像作成 設定
		Draw_Image di = new Draw_Image("Resource/checkButton.png", 795,620);
		di.setVisible(false);
		copyris_window.add(di);

		//JLabel作成
		JLabel jl = new JLabel("コピーしました");
		jl.setFont(new Font("MS UI Gothic", Font.PLAIN, 30));
		jl.setForeground(Color.BLACK);
		jl.setBounds(500, 650, 200, 30);
		jl.setVisible(false);

		//コピー用ボタンの設定 セットまで
		int Button_x = BUTTON_START_X;
		int Button_y = BUTTON_START_Y;
		int Button_width = 200;
		int Button_Height = 50;
		int roop_Count = 0;


		for(int i = 0;i < 18;i++){
			Draw_Button copyris_Button = new Draw_Button(binstr[i], Button_x, Button_y, Button_width, Button_Height,jl,cb,copyris_window,i,binstr);
			copyris_window.add(copyris_Button);

			if(roop_Count < 2) {
				roop_Count++;
				Button_x += BUTTON_PLUS_X;
			}	else if(roop_Count >= 2) {
					Button_x = BUTTON_START_X;
					Button_y += BUTTON_PLUS_Y;
					roop_Count = 0;
				}
			}

		//常に最前面に表示させるボタンの設定
		Draw_Button_OnTop dbo = new Draw_Button_OnTop(850, 620, 200, 50, jl, cb, copyris_window,di);

		copyris_window.add(dbo);

		copyris_window.add(jl);

		//ウィンドウの表示
		copyris_window.setVisible(true);

	}

	//ファイルパスの確認
	static boolean fileExists(String fileName) {

        String filePath = fileName;

        // Fileオブジェクトの生成
        File file = new File(filePath);

        // ファイルの存在を確認
        Boolean fileExists = file.exists();

        if (fileExists) {
            return true;

        } else {
            return false;
        }

    }

	static void InitStrData() {
		try{
			ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("Text/Button_Data.bin"));

			dataCreate = new Data_Create();
			for(int i = 0;i < 18;i++) {
				dataCreate.SetData(i, (i + 1) + " : 右クリックで編集");
			}
			oos.writeObject(dataCreate);
			oos.close();

			System.out.println("ファイルが生成されました");
		}catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
